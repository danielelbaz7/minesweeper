//
// Created by Daniel Elbaz on 12/4/24.
//

#include <iostream>

#include "minesweeper.h"
#include "Toolbox.h"

void restart() {
    delete Toolbox::getInstance().gameState;
    Toolbox::getInstance().gameState = new GameState();
}

void render() {
    for(int i = 0; i < Toolbox::getInstance().yMineCount; i++) {
        for(int j = 0; j < Toolbox::getInstance().xMineCount; j++) {
            Toolbox::getInstance().gameState->getTile(j, i)->draw();
        }
    }
}

int launch() {
    while(Toolbox::getInstance().window.isOpen()) {
        render();
        Toolbox::getInstance().window.display();
    }
    return 0;
}
int main() {return launch();}
