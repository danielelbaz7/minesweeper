//
// Created by Daniel Elbaz on 12/4/24.
//

#include "Toolbox.h"
#include "minesweeper.h"

Toolbox& Toolbox::getInstance() {
    static Toolbox instance;
    return instance;
}

Toolbox::Toolbox(): window(sf::VideoMode(800, 600), "P4 - Minesweeper, Daniel Elbaz"), gameState(new GameState) {
    sf::Vector2f pos = sf::Vector2f(368, 512);
    newGameButton = new Button(pos, restart);
    sf::Vector2f pos1 = sf::Vector2f(600, 512);
    testButton1 = new Button(pos1, restart);

    xMineCount = gameState->xMines;
    yMineCount = gameState->yMines;
}

void Toolbox::callBoardOne() {
    delete getInstance().gameState;
    getInstance().gameState = new GameState("./MineSweeper/boards/testboard1.brd");
}

void Toolbox::callBoardTwo() {
    getInstance().gameState = new GameState("./MineSweeper/boards/testboard2.brd");
}




